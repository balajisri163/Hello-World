package com.crypto.info.ui.settings;

import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;

import com.crypto.info.R;

import net.cachapa.expandablelayout.ExpandableLayout;

public class SettingsFragment extends Fragment {
    View root;
    ExpandableLayout expandableLayout;
    LinearLayout donate;
    CardView btc,eth,bnb,usdt;
    TextView name,address,important;
    ImageView imageView,copytoclipboard;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        root = inflater.inflate(R.layout.fragment_settings, container, false);
        expandableLayout=root.findViewById(R.id.expandable_layout);
        donate=root.findViewById(R.id.donate);
        btc=root.findViewById(R.id.btc);
        eth=root.findViewById(R.id.eth);
        bnb=root.findViewById(R.id.bnb);
        usdt=root.findViewById(R.id.usdt);
        donate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (expandableLayout.isExpanded()) {
                    expandableLayout.collapse();
                } else {
                    expandableLayout.expand();
                }
            }
        });
        btc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               CreateAlertDialog("Deposit Bitcoin","1J7hQ2hkHPeqx9B9kU8Bhr295qrT7WBPSy","Please deposit only BTC to this address. If you deposit any other coins, it will be lost forever.","btcqr");
            }
        });
        eth.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CreateAlertDialog("Deposit Ethereum","0x3754aa3279bce007888406ef966d010100363740","Please deposit only ETH to this address. If you deposit any other coins, it will be lost forever.","ethqr");

            }
        });
        bnb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CreateAlertDialog("Deposit Binance","0x3754aa3279bce007888406ef966d010100363740","Please deposit only BNB to this address. If you deposit any other coins, it will be lost forever.","bnbqr");

            }
        });
        usdt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CreateAlertDialog("Deposit Tether","TCQ7QNoQEwjisMK1EZXCJTFKeKVakio18A","Please deposit only USDT to this address. If you deposit any other coins, it will be lost forever.","usdtqr");

            }
        });

        return root;
    }


    public void CreateAlertDialog(String name_text,String address_text,String important_text,String qrcode){
        LayoutInflater factory = LayoutInflater.from(getContext());
        final View addDialogView = factory.inflate(R.layout.dialog_btc_donation, null);
        AlertDialog addDialog = new AlertDialog.Builder(getContext()).create();
        addDialog.setView(addDialogView);
        addDialog.setCanceledOnTouchOutside(true);
        addDialog.show();
        name=addDialog.findViewById(R.id.name);
        address=addDialog.findViewById(R.id.address);
        important=addDialog.findViewById(R.id.important_info);
        imageView=addDialog.findViewById(R.id.qr_code);
        copytoclipboard=addDialog.findViewById(R.id.copytoclipboard);
        name.setText(name_text);
        address.setText(address_text);
        important.setText(important_text);
        int id = getContext().getResources().getIdentifier(qrcode, "drawable", getContext().getPackageName());
        imageView.setImageResource(id);
        copytoclipboard.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onClick(View v) {
                ClipboardManager clipboard = (ClipboardManager) getActivity().getSystemService(Context.CLIPBOARD_SERVICE);
                ClipData clip = ClipData.newPlainText("Crypto Address", address_text);
                clipboard.setPrimaryClip(clip);
                Toast.makeText(getContext(),"Address copied to clipboard",Toast.LENGTH_LONG).show();
            }
        });
    }
}