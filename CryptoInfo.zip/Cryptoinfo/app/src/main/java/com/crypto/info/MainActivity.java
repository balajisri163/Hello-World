package com.crypto.info;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import com.crypto.info.network.RetrofitClient;
import com.crypto.info.network.reponse.GlobalMarket;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.messaging.RemoteMessage;
import com.pusher.pushnotifications.PushNotificationReceivedListener;
import com.pusher.pushnotifications.PushNotifications;

import androidx.annotation.RequiresApi;
import androidx.annotation.WorkerThread;
import androidx.appcompat.app.AlertDialog;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends BaseActivity {

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        getWindow().setStatusBarColor(Color.parseColor("#03045E"));
        getWindow().setNavigationBarColor(Color.parseColor("#03045E"));

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        BottomNavigationView navView = findViewById(R.id.nav_view);
        AppBarConfiguration appBarConfiguration = new AppBarConfiguration.Builder(
                R.id.navigation_home, R.id.navigation_dashboard, R.id.navigation_notifications)
                .build();
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment);
        NavigationUI.setupWithNavController(navView, navController);
        
        PushNotifications.start(getApplicationContext(), "df5a1a3c-7d0e-4860-9ddc-03e48765f48f");
        PushNotifications.addDeviceInterest("balaji");

    }


    @Override
    protected void onResume() {
        super.onResume();
        PushNotifications.setOnMessageReceivedListenerForVisibleActivity(this, new PushNotificationReceivedListener() {
            @Override
            public void onMessageReceived(RemoteMessage remoteMessage) {
                String message = remoteMessage.getData().get("inAppNotificationMessage");
                String title =remoteMessage.getNotification().getTitle();
                String body = remoteMessage.getNotification().getBody();
                if (message == null) {
                    Log.i("MyActivity", "Payload was missing");
                } else {
                    Log.i("MyActivity", message);
                    workerThread(message,title,body);
                }
            }
        });
    }


    private void CreateAlert(String alertmessage,String Title,String body){

        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(MainActivity.this);
        alertDialogBuilder.setTitle(Title);
        alertDialogBuilder.setMessage(body.concat("\n").concat(alertmessage))
                .setCancelable(false)
                .setPositiveButton("Yes",
                        new DialogInterface.OnClickListener(){
                            public void onClick(DialogInterface dialog, int id){
                                dialog.cancel();
                            }
                        });
        AlertDialog alert = alertDialogBuilder.create();
        alert.show();
    }

    @WorkerThread
    void workerThread(String alertMessage,String Title,String Body) {
        MainActivity.this.runOnUiThread(() -> {
            CreateAlert(alertMessage,Title,Body);
        });
    }





}