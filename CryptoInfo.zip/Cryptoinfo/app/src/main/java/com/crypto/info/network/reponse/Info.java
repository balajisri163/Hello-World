package com.crypto.info.network.reponse;

public class Info {
    String coins_num;
    String time;

}
