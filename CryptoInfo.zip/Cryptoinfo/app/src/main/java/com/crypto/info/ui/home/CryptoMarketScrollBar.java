package com.crypto.info.ui.home;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.crypto.info.R;
import com.crypto.info.network.reponse.CryptoCurrencyStat;
import com.crypto.info.ui.markets.CryptoItemAdaptor;

import java.util.List;

public class CryptoMarketScrollBar extends RecyclerView.Adapter<CryptoMarketScrollBar.ViewHolder>{

    private Context mctx;
    private List<CryptoCurrencyStat> cryptoCurrencyStats;

    public CryptoMarketScrollBar(Context mctx, List<CryptoCurrencyStat> cryptoCurrencyStats) {
        this.mctx = mctx;
        this.cryptoCurrencyStats = cryptoCurrencyStats;
    }

    @NonNull
    @Override
    public CryptoMarketScrollBar.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int i) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_crypto_announcement, parent, false);

        return new CryptoMarketScrollBar.ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull CryptoMarketScrollBar.ViewHolder holder, int position) {

        final CryptoCurrencyStat report = cryptoCurrencyStats.get(position);
        holder.symbol.setText(report.getSymbol());
        holder.price_usd.setText(report.getPrice_usd());
        holder.name.setText(report.getName());
        holder.twenty_four_change.setText(report.getPercent_change_24h().concat("%"));
        String imageres= report.getSymbol().toLowerCase();
        int id = mctx.getResources().getIdentifier(imageres, "drawable", mctx.getPackageName());
        float change= Float.parseFloat(report.getPercent_change_24h());
        if(change<=0){
            holder.indicator.setImageResource(R.drawable.ic_downward);
        }else {
            holder.indicator.setImageResource(R.drawable.ic_upward);
        }

        if(id==0){
            holder.imageView.setImageResource(R.drawable.generic);
        }else{
            holder.imageView.setImageResource(id);
        }

    }

    @Override
    public int getItemCount() {
        return cryptoCurrencyStats.size();
    }

    public void notifyData(List<CryptoCurrencyStat> cryptoCurrencyStats) {
        this.cryptoCurrencyStats = cryptoCurrencyStats;
        notifyDataSetChanged();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        TextView symbol, price_usd,name,twenty_four_change;
        ImageView imageView,indicator;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            symbol = itemView.findViewById(R.id.symbol);
            price_usd = itemView.findViewById(R.id.price_usd);
            name = itemView.findViewById(R.id.name);
            twenty_four_change = itemView.findViewById(R.id.twenty_four_change);
            imageView=itemView.findViewById(R.id.cryptologo);
            indicator=itemView.findViewById(R.id.indicator);
        }
    }

    public void clear() {
        cryptoCurrencyStats.clear();
        notifyDataSetChanged();
    }

    public void addAll(List<CryptoCurrencyStat> list) {
        cryptoCurrencyStats.addAll(list);
        notifyDataSetChanged();
    }


}
