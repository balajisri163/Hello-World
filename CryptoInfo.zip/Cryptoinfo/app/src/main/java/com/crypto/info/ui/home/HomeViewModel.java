package com.crypto.info.ui.home;

import android.util.Log;
import android.widget.Toast;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.crypto.info.MainActivity;
import com.crypto.info.network.RetrofitClient;
import com.crypto.info.network.reponse.CryptoCurrencyStat;
import com.crypto.info.network.reponse.GlobalMarket;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class HomeViewModel extends ViewModel {

    private MutableLiveData<GlobalMarket> globalMarketMutableLiveData;

    public HomeViewModel() {
        globalMarketMutableLiveData = new MutableLiveData<>();
    }

    public void init(){
        callGlobalMarket();
    }


    public LiveData<GlobalMarket> getText() {
        return globalMarketMutableLiveData;
    }



    private void callGlobalMarket() {
        Call<List<GlobalMarket>> call = RetrofitClient.getInstance().getApi().globalmarket();
        call.enqueue(new Callback<List<GlobalMarket>>() {
            @Override
            public void onResponse(Call<List<GlobalMarket>> call, Response<List<GlobalMarket>> response) {
                if (response.isSuccessful()) {
                    List<GlobalMarket> globalmarket=response.body();
                    globalMarketMutableLiveData.postValue(globalmarket.get(0));
                }
            }
            @Override
            public void onFailure(Call<List<GlobalMarket>> call, Throwable t) {
                globalMarketMutableLiveData.postValue(null);
            }
        });

    }

}