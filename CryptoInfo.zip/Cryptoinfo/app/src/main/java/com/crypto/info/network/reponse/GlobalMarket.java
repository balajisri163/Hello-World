package com.crypto.info.network.reponse;

public class GlobalMarket {
    float coins_count;
    float active_markets;
    float total_mcap;
    float total_volume;
    String  btc_d;
    String  eth_d;
    String  mcap_change;
    String  volume_change;
    String  avg_change_percent;
    float volume_ath;
    float mcap_ath;


    public float getCoins_count() {
        return coins_count;
    }

    public void setCoins_count(float coins_count) {
        this.coins_count = coins_count;
    }

    public float getActive_markets() {
        return active_markets;
    }

    public void setActive_markets(float active_markets) {
        this.active_markets = active_markets;
    }

    public float getTotal_mcap() {
        return total_mcap;
    }

    public void setTotal_mcap(float total_mcap) {
        this.total_mcap = total_mcap;
    }

    public float getTotal_volume() {
        return total_volume;
    }

    public void setTotal_volume(float total_volume) {
        this.total_volume = total_volume;
    }

    public String getBtc_d() {
        return btc_d;
    }

    public void setBtc_d(String btc_d) {
        this.btc_d = btc_d;
    }

    public String getEth_d() {
        return eth_d;
    }

    public void setEth_d(String eth_d) {
        this.eth_d = eth_d;
    }

    public String getMcap_change() {
        return mcap_change;
    }

    public void setMcap_change(String mcap_change) {
        this.mcap_change = mcap_change;
    }

    public String getVolume_change() {
        return volume_change;
    }

    public void setVolume_change(String volume_change) {
        this.volume_change = volume_change;
    }

    public String getAvg_change_percent() {
        return avg_change_percent;
    }

    public void setAvg_change_percent(String avg_change_percent) {
        this.avg_change_percent = avg_change_percent;
    }

    public float getVolume_ath() {
        return volume_ath;
    }

    public void setVolume_ath(float volume_ath) {
        this.volume_ath = volume_ath;
    }

    public float getMcap_ath() {
        return mcap_ath;
    }

    public void setMcap_ath(float mcap_ath) {
        this.mcap_ath = mcap_ath;
    }
}
