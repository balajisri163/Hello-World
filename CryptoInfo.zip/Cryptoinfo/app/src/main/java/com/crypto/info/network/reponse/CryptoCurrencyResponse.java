package com.crypto.info.network.reponse;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class CryptoCurrencyResponse {
    @SerializedName("data")
    private List<CryptoCurrencyStat> cryptoCurrencyStats;

    @SerializedName("info")
    private Info info;

    public List<CryptoCurrencyStat> getCryptoCurrencyStats() {
        return cryptoCurrencyStats;
    }

    public void setCryptoCurrencyStats(List<CryptoCurrencyStat> cryptoCurrencyStats) {
        this.cryptoCurrencyStats = cryptoCurrencyStats;
    }

    public Info getInfo() {
        return info;
    }

    public void setInfo(Info info) {
        this.info = info;
    }
}
