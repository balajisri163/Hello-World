package com.crypto.info.ui.home;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.constraintlayout.helper.widget.Carousel;
import androidx.constraintlayout.motion.widget.MotionLayout;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.LinearSnapHelper;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.SnapHelper;

import com.crypto.info.R;
import com.crypto.info.network.RetrofitClient;
import com.crypto.info.network.reponse.CryptoCurrencyResponse;
import com.crypto.info.network.reponse.CryptoCurrencyStat;
import com.crypto.info.network.reponse.GlobalMarket;
import com.crypto.info.ui.markets.CryptoItemAdaptor;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Timer;
import java.util.TimerTask;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class HomeFragment extends Fragment {

    private HomeViewModel homeViewModel;
    TextView coin_count,market_cap,h_vol,markets,btc_vol,eth_vol;
    ProgressBar progressBar;
    LinearLayout linearLayout;
    RecyclerView marketcycle;
    CryptoMarketScrollBar cryptoMarketScrollBar;
    List<CryptoCurrencyStat> cryptoCurrencyStatList;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        homeViewModel =
                new ViewModelProvider(this).get(HomeViewModel.class);
        homeViewModel.init();
        View root = inflater.inflate(R.layout.fragment_home, container, false);
        coin_count = root.findViewById(R.id.coin_count);
        market_cap=root.findViewById(R.id.market_cap);
        h_vol=root.findViewById(R.id.h_vol);
        markets=root.findViewById(R.id.markets);
        btc_vol=root.findViewById(R.id.btc_vol);
        eth_vol=root.findViewById(R.id.eth_vol);
        progressBar=root.findViewById(R.id.progressBar_cyclic);
        linearLayout=root.findViewById(R.id.mainll);
        progressBar.setVisibility(View.VISIBLE);
        linearLayout.setVisibility(View.GONE);
        marketcycle=root.findViewById(R.id.market_cycle);

        marketcycle.setHasFixedSize(true);
        marketcycle.setLayoutManager(new LinearLayoutManager(getActivity()));
        cryptoCurrencyStatList = new ArrayList<>();
        cryptoMarketScrollBar = new CryptoMarketScrollBar(getActivity(), cryptoCurrencyStatList);
        marketcycle.setAdapter(cryptoMarketScrollBar);

        callCryptocurrencyStats();
        homeViewModel.getText().observe(getViewLifecycleOwner(), new Observer<GlobalMarket>() {
            @Override
            public void onChanged(@Nullable GlobalMarket s) {
                coin_count.setText(String.valueOf(s.getCoins_count()));
                market_cap.setText("$".concat(String.format(Locale.ENGLISH,"%.0f",s.getTotal_mcap())));
                h_vol.setText("$".concat(String.format(Locale.ENGLISH,"%.0f",s.getTotal_volume())));
                markets.setText(String.valueOf(s.getActive_markets()));
                btc_vol.setText(s.getBtc_d().concat("%"));
                eth_vol.setText(s.getEth_d().concat("%"));
                progressBar.setVisibility(View.GONE);
                linearLayout.setVisibility(View.VISIBLE);
            }
        });

       LinearLayoutManager HorizontalLayout = new LinearLayoutManager(getContext(), LinearLayoutManager.HORIZONTAL, false);
        marketcycle.setLayoutManager(HorizontalLayout);
        SnapHelper helper = new LinearSnapHelper();
        helper.attachToRecyclerView(marketcycle);
        Timer myTimer = new Timer();

        final Handler h = new Handler(Looper.getMainLooper());
        h.postDelayed(new Runnable() {
            @Override
            public void run() {
                marketcycle.smoothScrollToPosition(HorizontalLayout.findFirstVisibleItemPosition() + 1);

                h.postDelayed(this, 5000);
            }
        }, 5000);

        marketcycle.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(RecyclerView recyclerView, int newState) {
                super.onScrollStateChanged(recyclerView, newState);

                if (!recyclerView.canScrollHorizontally(1) && newState == RecyclerView.SCROLL_STATE_IDLE) {
                    Log.d("-----", "end");
                    myTimer.schedule(new TimerTask() {
                        @Override
                        public void run() {
                            recyclerView.smoothScrollToPosition(0);
                        }
                    }, 5000);
                }
            }
        });



        return root;
    }


    private void callCryptocurrencyStats() {
        Call<CryptoCurrencyResponse> call = RetrofitClient.getInstance().getApi().cryptostats(0,10);
        call.enqueue(new Callback<CryptoCurrencyResponse>() {
            @Override
            public void onResponse(Call<CryptoCurrencyResponse> call, Response<CryptoCurrencyResponse> response) {
                if (response.isSuccessful()) {
                    CryptoCurrencyResponse cryptoCurrencyResponse=response.body();
                    cryptoMarketScrollBar.clear();
                    assert cryptoCurrencyResponse != null;
                    cryptoCurrencyStatList.clear();
                    cryptoCurrencyStatList.addAll(cryptoCurrencyResponse.getCryptoCurrencyStats());
                    cryptoMarketScrollBar.notifyData(cryptoCurrencyStatList);
                }
            }
            @Override
            public void onFailure(Call<CryptoCurrencyResponse> call, Throwable t) {
                Toast.makeText(getContext(),"Network error",Toast.LENGTH_LONG).show();
            }
        });

    }




}