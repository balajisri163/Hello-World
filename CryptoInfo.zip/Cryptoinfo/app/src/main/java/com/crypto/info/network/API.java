package com.crypto.info.network;

import com.crypto.info.network.reponse.CryptoCurrencyResponse;
import com.crypto.info.network.reponse.GlobalMarket;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface API {
    @GET("global")
    Call<List<GlobalMarket>> globalmarket();

    @GET("tickers")
    Call<CryptoCurrencyResponse> cryptostats(
            @Query("start") int start,
            @Query("limit") int limit
    );

}
