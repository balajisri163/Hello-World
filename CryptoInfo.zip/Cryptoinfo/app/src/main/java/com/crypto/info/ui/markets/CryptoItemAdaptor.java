package com.crypto.info.ui.markets;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.RecyclerView;

import com.crypto.info.R;
import com.crypto.info.network.reponse.CryptoCurrencyStat;

import java.util.List;

public class CryptoItemAdaptor extends RecyclerView.Adapter<CryptoItemAdaptor.ViewHolder> {
    private Context mctx;
    private List<CryptoCurrencyStat> cryptoCurrencyStats;

    public CryptoItemAdaptor(Context mctx, List<CryptoCurrencyStat> cryptoCurrencyStats) {
        this.mctx = mctx;
        this.cryptoCurrencyStats = cryptoCurrencyStats;
    }

    @NonNull
    @Override
    public CryptoItemAdaptor.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int i) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_crypto_asset, parent, false);

        return new CryptoItemAdaptor.ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull CryptoItemAdaptor.ViewHolder holder, int position) {

        final CryptoCurrencyStat report = cryptoCurrencyStats.get(position);
            holder.symbol.setText(report.getSymbol());
            holder.price_usd.setText(report.getPrice_usd());
            holder.name.setText(report.getName());
            holder.price_btc.setText(report.getPrice_btc());
            holder.one_hour.setText(report.getPercent_change_1h().concat("%"));
            holder.twenty_four_change.setText(report.getPercent_change_24h().concat("%"));
            holder.seven_day_change.setText(report.getPercent_change_7d().concat("%"));
            String vol24=truncateNumber(report.getVolume24());
            String market_cap= truncateNumber(Float.parseFloat(report.getMarket_cap_usd()));
            holder.volume_24.setText("$".concat(vol24));
            holder.market_cap.setText("$".concat(market_cap));
            String imageres= report.getSymbol().toLowerCase();
            int id = mctx.getResources().getIdentifier(imageres, "drawable", mctx.getPackageName());
            if(id==0){
                holder.imageView.setImageResource(R.drawable.generic);
            }else{
                holder.imageView.setImageResource(id);
            }
            holder.cardView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Bundle bundle = new Bundle();
                    bundle.putString("symbol", report.getSymbol());
                    AppCompatActivity activity = (AppCompatActivity) mctx;
                    NavController navController = Navigation.findNavController(activity, R.id.nav_host_fragment);
                    navController.navigate(R.id.action_navigation_dashboard_to_navigation_crypto,bundle);

                }
            });
    }

    @Override
    public int getItemCount() {
        return cryptoCurrencyStats.size();
    }

    public void notifyData(List<CryptoCurrencyStat> cryptoCurrencyStats) {
        this.cryptoCurrencyStats = cryptoCurrencyStats;
        notifyDataSetChanged();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        TextView symbol, price_usd,name,one_hour,twenty_four_change,seven_day_change,market_cap,volume_24,price_btc;
        ImageView imageView;
        CardView cardView;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            symbol = itemView.findViewById(R.id.symbol);
            price_usd = itemView.findViewById(R.id.price_usd);
            name= itemView.findViewById(R.id.name);
            one_hour= itemView.findViewById(R.id.one_hour);
            twenty_four_change= itemView.findViewById(R.id.twenty_four_change);
            seven_day_change= itemView.findViewById(R.id.seven_day_change);
            market_cap= itemView.findViewById(R.id.market_cap);
            volume_24= itemView.findViewById(R.id.volume_24);
            price_btc= itemView.findViewById(R.id.price_btc);
            imageView=itemView.findViewById(R.id.cryptologo);
            cardView=itemView.findViewById(R.id.content);
        }
    }

    public void clear() {
        cryptoCurrencyStats.clear();
        notifyDataSetChanged();
    }

    public void addAll(List<CryptoCurrencyStat> list) {
        cryptoCurrencyStats.addAll(list);
        notifyDataSetChanged();
    }


    public String truncateNumber(float floatNumber) {
        long million = 1000000L;
        long billion = 1000000000L;
        long trillion = 1000000000000L;
        long number = Math.round(floatNumber);
        if ((number >= million) && (number < billion)) {
            float fraction = calculateFraction(number, million);
            return Float.toString(fraction) + "M";
        } else if ((number >= billion) && (number < trillion)) {
            float fraction = calculateFraction(number, billion);
            return Float.toString(fraction) + "B";
        }
        return Long.toString(number);
    }

    public float calculateFraction(long number, long divisor) {
        long truncate = (number * 10L + (divisor / 2L)) / divisor;
        float fraction = (float) truncate * 0.10F;
        return fraction;
    }


}
