package com.crypto.info.ui.markets;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.crypto.info.R;
import com.crypto.info.network.RetrofitClient;
import com.crypto.info.network.reponse.CryptoCurrencyResponse;
import com.crypto.info.network.reponse.CryptoCurrencyStat;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class DashboardFragment extends Fragment {

    View view;
    SwipeRefreshLayout swipeRefreshLayout;
    RecyclerView recyclerView;
    List<CryptoCurrencyStat> cryptoCurrencyStatList;
    CryptoItemAdaptor cryptoItemAdaptor;
    ProgressBar progressBar;
    EditText search;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_dashboard, container, false);
        recyclerView= view.findViewById(R.id.cryptoitems);
        progressBar=view.findViewById(R.id.progressBar_cyclic);
        swipeRefreshLayout= view.findViewById(R.id.swiperefreshlayout);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        cryptoCurrencyStatList = new ArrayList<>();
        cryptoItemAdaptor = new CryptoItemAdaptor(getActivity(), cryptoCurrencyStatList);
        recyclerView.setAdapter(cryptoItemAdaptor);
        search=view.findViewById(R.id.search_bar);

        progressBar.setVisibility(View.VISIBLE);
        swipeRefreshLayout.setVisibility(View.GONE);
        callCryptocurrencyStats();

        swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                callCryptocurrencyStats();
            }
        });

        search.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                search_employee(charSequence.toString());
            }

            @Override
            public void afterTextChanged(Editable s) {

                search_employee(s.toString());
            }
        });

        return view;
    }


    private void callCryptocurrencyStats() {
        Call<CryptoCurrencyResponse> call = RetrofitClient.getInstance().getApi().cryptostats(0,200);
        call.enqueue(new Callback<CryptoCurrencyResponse>() {
            @Override
            public void onResponse(Call<CryptoCurrencyResponse> call, Response<CryptoCurrencyResponse> response) {
                if (response.isSuccessful()) {
                    CryptoCurrencyResponse cryptoCurrencyResponse=response.body();
                    cryptoItemAdaptor.clear();
                    assert cryptoCurrencyResponse != null;
                    cryptoCurrencyStatList.clear();
                    cryptoCurrencyStatList.addAll(cryptoCurrencyResponse.getCryptoCurrencyStats());
                    cryptoItemAdaptor.notifyData(cryptoCurrencyStatList);
                    swipeRefreshLayout.setRefreshing(false);
                    progressBar.setVisibility(View.GONE);
                    swipeRefreshLayout.setVisibility(View.VISIBLE);
                }
            }
            @Override
            public void onFailure(Call<CryptoCurrencyResponse> call, Throwable t) {
                Toast.makeText(getContext(),"Network error",Toast.LENGTH_LONG).show();
            }
        });

    }

    private void search_employee(String text) {
        List<CryptoCurrencyStat> filteredList = new ArrayList<>();
        for (CryptoCurrencyStat item : cryptoCurrencyStatList) {
            if (item.getName().toLowerCase().contains(text.toLowerCase())) {
                filteredList.add(item);
            }else if(item.getSymbol().toLowerCase().contains(text.toLowerCase())){
                filteredList.add(item);
            }
        }
        cryptoItemAdaptor.notifyData(filteredList);
    }

}